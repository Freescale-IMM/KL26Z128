/*
 * main implementation: use this 'C' sample to create your own application
 *
 */
///////////////////////////////////////////////////////////////////
//
// Sections testram and myram are added in linker file
// vraibles and codes can be placed in the section.
// User needs to save the code in Flash or external memory, load it
// into RAM before executing.
//
// Disconnect the debugger, power on and off the target board to check the effect
///////////////////////////////////////////////////////////////////

#include "derivative.h" /* include peripheral declarations */

#define DELAY_COUNT 1000000

#define RED 29
#define RED_SHIFT (1U << 29)

#define GREEN 31
#define GREEN_SHIFT (1U << 31)

#define RED_ON (GPIOE_PCOR = RED_SHIFT)
#define RED_OFF (GPIOE_PSOR = RED_SHIFT)
#define RED_TOGGLE (GPIOE_PTOR = RED_SHIFT)

#define GREEN_ON (GPIOE_PCOR = GREEN_SHIFT)
#define GREEN_OFF (GPIOE_PSOR = GREEN_SHIFT)
#define GREEN_TOGGLE (GPIOE_PTOR = GREEN_SHIFT)

__attribute__ ((section(".myram"))) unsigned char array[10];

#define mySection __attribute__((section(".testram"), long_call))

void mySection testmend(void)
{
   __asm(" NOP"); 
}

 // Define function in section testram
unsigned int mySection test_function01(unsigned int n) {

   static unsigned int counter = 0;
   
   counter += n;
//   RED_TOGGLE;
   GREEN_TOGGLE;
   return 0;   
 } 

// test_function01 generated code in .s19 These code can be saved in external
// flash or EEPROM and laoded before executing
// S3151FFFF000  80B582B000AF7860074B1A687B68D218  4D
// S3151FFFF010  054B1A60054B80229205DA600023181C  E8
// S3151FFFF020  BD4602B080BDC0460400002000F10F40  60
// Toggle RED LED
const char flash_code1[0x30] = {
   0x80,0xB5,0x82,0xB0,0x00,0xAF,0x78,0x60,0x07,0x4B,0x1A,0x68,0x7B,0x68,0xD2,0x18,
   0x05,0x4B,0x1A,0x60,0x05,0x4B,0x80,0x22,0x92,0x05,0xDA,0x60,0x00,0x23,0x18,0x1C,
   0xBD,0x46,0x02,0xB0,0x80,0xBD,0xC0,0x46,0x04,0x00,0x00,0x20,0x00,0xF1,0x0F,0x40
};

// test_function01 generated code in .s19
// S3151FFFF000  80B582B000AF7860074B1A687B68D218  4D
// S3151FFFF010  054B1A60054B80221206DA600023181C  67
// S3151FFFF020  BD4602B080BDC0460400002000F10F40  60
// Toggle GREEN LED
const char flash_code2[0x30] = {
   0x80,0xB5,0x82,0xB0,0x00,0xAF,0x78,0x60,0x07,0x4B,0x1A,0x68,0x7B,0x68,0xD2,0x18,
   0x05,0x4B,0x1A,0x60,0x05,0x4B,0x80,0x22,0x12,0x06,0xDA,0x60,0x00,0x23,0x18,0x1C,
   0xBD,0x46,0x02,0xB0,0x80,0xBD,0xC0,0x46,0x04,0x00,0x00,0x20,0x00,0xF1,0x0F,0x40
};

// delay fuction used for demo
void delay(unsigned long counter) {
  unsigned int j;
  for(j = 0;j < counter;j ++) {
  }
}
 
void CopyCode2RAM(char *src, char *dest, long size) { 

  if (dest != src) 
  while (size--) 
    *dest++ = *src++; 

}

int main(void)
{
	unsigned char i;
	
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;      //Turn on clock to PortE module
	    
	PORTE_PCR29 = PORT_PCR_MUX(0x1);          //Set the PTE29 pin multiplexer to GPIO mode
	PORTE_PCR31 = PORT_PCR_MUX(0x1);           //Set the PTE31 pin multiplexer to GPIO mode
	    
	GPIOE_PSOR |= RED_SHIFT;                //Set the initial output state to high
	GPIOE_PSOR |= GREEN_SHIFT;               //Set the inital output state to high
	    
	GPIOE_PDDR |= RED_SHIFT;                //Set the pin's direction to output
	GPIOE_PDDR |= GREEN_SHIFT;               //Set the pin's direction to output
	    
	RED_ON;			//Turn on RED LED
	GREEN_OFF;		//Turn off GREEN LED
	testmend();
	for(i = 0;i < 10;i ++)
		array[i] = i;
	
//	CopyCode2RAM((char*)flash_code1, ((char *)0x1FFFF000), 0x30);
//	CopyCode2RAM((char*)flash_code2, ((char *)0x1FFFF000), 0x30);
	  
	for(;;) {	   
		delay(1000000);
	   	test_function01(5);
	}
	
	return 0;
}
